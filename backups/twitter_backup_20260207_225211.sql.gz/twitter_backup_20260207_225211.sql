--
-- PostgreSQL database dump
--

\restrict ectY4a8qFFnFHvZGcANtco9gXhEaQZ64Kmi1SJ9p2NWnUpdeRJ4FFQyKioP4Wnx

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_following_id_fkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_follower_id_fkey;
ALTER TABLE IF EXISTS public.tweets DROP CONSTRAINT IF EXISTS fk_tweets_user;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_tweets_updated_at ON public.tweets;
DROP TRIGGER IF EXISTS tweet_count_trigger ON public.tweets;
DROP TRIGGER IF EXISTS retweet_count_trigger ON public.retweets;
DROP TRIGGER IF EXISTS like_count_trigger ON public.likes;
DROP TRIGGER IF EXISTS follow_counts_trigger ON public.follows;
DROP INDEX IF EXISTS public.tweets_2026_q4_user_id_created_at_idx;
DROP INDEX IF EXISTS public.tweets_2024_q1_user_id_created_at_idx;
DROP INDEX IF EXISTS public.idx_tweets_timeline;
DROP INDEX IF EXISTS public.idx_trending_hashtags;
DROP INDEX IF EXISTS public.idx_retweets_user;
DROP INDEX IF EXISTS public.idx_retweets_tweet;
DROP INDEX IF EXISTS public.idx_likes_user;
DROP INDEX IF EXISTS public.idx_likes_tweet;
DROP INDEX IF EXISTS public.idx_follows_following;
DROP INDEX IF EXISTS public.idx_follows_follower;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.tweets_default DROP CONSTRAINT IF EXISTS tweets_default_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q4 DROP CONSTRAINT IF EXISTS tweets_2026_q4_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q3 DROP CONSTRAINT IF EXISTS tweets_2026_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q2 DROP CONSTRAINT IF EXISTS tweets_2026_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q1 DROP CONSTRAINT IF EXISTS tweets_2026_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q4 DROP CONSTRAINT IF EXISTS tweets_2025_q4_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q3 DROP CONSTRAINT IF EXISTS tweets_2025_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q2 DROP CONSTRAINT IF EXISTS tweets_2025_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q1 DROP CONSTRAINT IF EXISTS tweets_2025_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q4 DROP CONSTRAINT IF EXISTS tweets_2024_q4_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q3 DROP CONSTRAINT IF EXISTS tweets_2024_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q2 DROP CONSTRAINT IF EXISTS tweets_2024_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets DROP CONSTRAINT IF EXISTS tweets_pkey1;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q1 DROP CONSTRAINT IF EXISTS tweets_2024_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_user_id_tweet_id_key;
ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_pkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_user_id_tweet_id_key;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_pkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_pkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_follower_id_following_id_key;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tweets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.retweets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.likes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.follows ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP VIEW IF EXISTS public.user_timeline;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tweets_default;
DROP TABLE IF EXISTS public.tweets_2026_q4;
DROP TABLE IF EXISTS public.tweets_2026_q3;
DROP TABLE IF EXISTS public.tweets_2026_q2;
DROP TABLE IF EXISTS public.tweets_2026_q1;
DROP TABLE IF EXISTS public.tweets_2025_q4;
DROP TABLE IF EXISTS public.tweets_2025_q3;
DROP TABLE IF EXISTS public.tweets_2025_q2;
DROP TABLE IF EXISTS public.tweets_2025_q1;
DROP TABLE IF EXISTS public.tweets_2024_q4;
DROP TABLE IF EXISTS public.tweets_2024_q3;
DROP TABLE IF EXISTS public.tweets_2024_q2;
DROP TABLE IF EXISTS public.tweets_2024_q1;
DROP SEQUENCE IF EXISTS public.tweets_id_seq1;
DROP MATERIALIZED VIEW IF EXISTS public.trending_hashtags;
DROP TABLE IF EXISTS public.tweets;
DROP SEQUENCE IF EXISTS public.retweets_id_seq1;
DROP SEQUENCE IF EXISTS public.retweets_id_seq;
DROP TABLE IF EXISTS public.retweets;
DROP SEQUENCE IF EXISTS public.likes_id_seq;
DROP TABLE IF EXISTS public.likes;
DROP SEQUENCE IF EXISTS public.follows_id_seq;
DROP TABLE IF EXISTS public.follows;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_tweet_count();
DROP FUNCTION IF EXISTS public.update_retweet_count();
DROP FUNCTION IF EXISTS public.update_like_count();
DROP FUNCTION IF EXISTS public.update_follow_counts();
DROP SCHEMA IF EXISTS datadog;
--
-- Name: datadog; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA datadog;


--
-- Name: update_follow_counts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_follow_counts() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE users SET following_count = following_count + 1 WHERE id = NEW.follower_id;
        UPDATE users SET follower_count = follower_count + 1 WHERE id = NEW.following_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE users SET following_count = following_count - 1 WHERE id = OLD.follower_id;
        UPDATE users SET follower_count = follower_count - 1 WHERE id = OLD.following_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: update_like_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_like_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE tweets SET like_count = like_count + 1 WHERE id = NEW.tweet_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE tweets SET like_count = like_count - 1 WHERE id = OLD.tweet_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: update_retweet_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_retweet_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE tweets SET retweet_count = retweet_count + 1 WHERE id = NEW.tweet_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE tweets SET retweet_count = retweet_count - 1 WHERE id = OLD.tweet_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: update_tweet_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_tweet_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE users SET tweet_count = tweet_count + 1 WHERE id = NEW.user_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE users SET tweet_count = tweet_count - 1 WHERE id = OLD.user_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_table_access_method = heap;

--
-- Name: follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.follows (
    id bigint NOT NULL,
    follower_id bigint NOT NULL,
    following_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT follows_check CHECK ((follower_id <> following_id))
);


--
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- Name: likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.likes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tweet_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: likes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.likes_id_seq OWNED BY public.likes.id;


--
-- Name: retweets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retweets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tweet_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- Name: retweets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.retweets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: retweets_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.retweets_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: retweets_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.retweets_id_seq1 OWNED BY public.retweets.id;


--
-- Name: tweets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
)
PARTITION BY RANGE (created_at);


--
-- Name: trending_hashtags; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.trending_hashtags AS
 SELECT unnest(tweets.hashtags) AS hashtag,
    count(*) AS tweet_count,
    max(tweets.created_at) AS last_used
   FROM public.tweets
  WHERE (tweets.created_at > (now() - '24:00:00'::interval))
  GROUP BY (unnest(tweets.hashtags))
  ORDER BY (count(*)) DESC
 LIMIT 100
  WITH NO DATA;


--
-- Name: tweets_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tweets_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: tweets_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tweets_id_seq1 OWNED BY public.tweets.id;


--
-- Name: tweets_2024_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2024_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2024_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2024_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2025_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2025_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2025_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2025_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2026_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2026_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2026_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_2026_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: tweets_default; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_default (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(15) NOT NULL,
    email character varying(254) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(50) NOT NULL,
    bio text,
    avatar_url text,
    verified boolean DEFAULT false,
    follower_count integer DEFAULT 0,
    following_count integer DEFAULT 0,
    tweet_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: user_timeline; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_timeline AS
 SELECT t.id,
    t.user_id,
    t.content,
    t.reply_to_tweet_id,
    t.media_urls,
    t.hashtags,
    t.mentions,
    t.like_count,
    t.retweet_count,
    t.reply_count,
    t.created_at,
    u.username,
    u.display_name,
    u.avatar_url,
    u.verified
   FROM (public.tweets t
     JOIN public.users u ON ((t.user_id = u.id)));


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: tweets_2024_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q2 FOR VALUES FROM ('2024-04-01 00:00:00+00') TO ('2024-07-01 00:00:00+00');


--
-- Name: tweets_2024_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q3 FOR VALUES FROM ('2024-07-01 00:00:00+00') TO ('2024-10-01 00:00:00+00');


--
-- Name: tweets_2024_q4; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q4 FOR VALUES FROM ('2024-10-01 00:00:00+00') TO ('2025-01-01 00:00:00+00');


--
-- Name: tweets_2025_q1; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q1 FOR VALUES FROM ('2025-01-01 00:00:00+00') TO ('2025-04-01 00:00:00+00');


--
-- Name: tweets_2025_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q2 FOR VALUES FROM ('2025-04-01 00:00:00+00') TO ('2025-07-01 00:00:00+00');


--
-- Name: tweets_2025_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q3 FOR VALUES FROM ('2025-07-01 00:00:00+00') TO ('2025-10-01 00:00:00+00');


--
-- Name: tweets_2025_q4; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q4 FOR VALUES FROM ('2025-10-01 00:00:00+00') TO ('2026-01-01 00:00:00+00');


--
-- Name: tweets_2026_q1; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q1 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- Name: tweets_2026_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q2 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- Name: tweets_2026_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q3 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


--
-- Name: tweets_default; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_default DEFAULT;


--
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- Name: likes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes ALTER COLUMN id SET DEFAULT nextval('public.likes_id_seq'::regclass);


--
-- Name: retweets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets ALTER COLUMN id SET DEFAULT nextval('public.retweets_id_seq1'::regclass);


--
-- Name: tweets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ALTER COLUMN id SET DEFAULT nextval('public.tweets_id_seq1'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.follows (id, follower_id, following_id, created_at) FROM stdin;
1	5	4	2026-02-08 02:57:33.241162+00
\.


--
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.likes (id, user_id, tweet_id, created_at) FROM stdin;
\.


--
-- Data for Name: retweets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retweets (id, user_id, tweet_id, created_at) FROM stdin;
\.


--
-- Data for Name: tweets_2024_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2024_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2024_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2024_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2025_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2025_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2025_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2025_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2026_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
6	4	Hi, This is first tweet from Era Chaudhary	\N	{}	{}	{}	0	0	0	2026-02-08 02:56:40.657326+00	2026-02-08 02:56:40.657326+00
7	4	Hi This is second from Era Chaudhary	\N	{}	{}	{}	0	0	0	2026-02-08 02:56:52.339378+00	2026-02-08 02:56:52.339378+00
8	5	Hi This is first tweet from Emma Claire	\N	{}	{}	{}	0	0	0	2026-02-08 02:57:51.071751+00	2026-02-08 02:57:51.071751+00
9	5	Hi This is second from Emma Claire	\N	{}	{}	{}	0	0	0	2026-02-08 02:58:03.279801+00	2026-02-08 02:58:03.279801+00
\.


--
-- Data for Name: tweets_2026_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2026_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_2026_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: tweets_default; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_default (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, display_name, bio, avatar_url, verified, follower_count, following_count, tweet_count, created_at, updated_at) FROM stdin;
4	eran2417	erachaudhary2417@gmail.com	$2a$12$S0S/JuWdzLdNw3f7yuUcPuo95Um28ozH2c.TxmCbxcQlcJv9hOW0K	Era Chaudhary	\N	\N	f	1	0	4	2026-02-08 02:56:28.437459+00	2026-02-08 03:39:47.81792+00
5	ec2693	ec2693@nyu.edu	$2a$12$x5dhDiJuBpwunaMhB3adCuXLu3p90CDVk4bpVpKYV7Y2nMfnrO43G	Emma Claire	\N	\N	f	0	1	4	2026-02-08 02:57:23.657021+00	2026-02-08 03:39:47.81792+00
\.


--
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.follows_id_seq', 1, true);


--
-- Name: likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.likes_id_seq', 1, false);


--
-- Name: retweets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retweets_id_seq', 1, false);


--
-- Name: retweets_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retweets_id_seq1', 1, false);


--
-- Name: tweets_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tweets_id_seq1', 9, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- Name: follows follows_follower_id_following_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_following_id_key UNIQUE (follower_id, following_id);


--
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- Name: likes likes_user_id_tweet_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_tweet_id_key UNIQUE (user_id, tweet_id);


--
-- Name: retweets retweets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_pkey PRIMARY KEY (id);


--
-- Name: retweets retweets_user_id_tweet_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_user_id_tweet_id_key UNIQUE (user_id, tweet_id);


--
-- Name: tweets_2024_q1 tweets_2024_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q1
    ADD CONSTRAINT tweets_2024_q1_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets tweets_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets
    ADD CONSTRAINT tweets_pkey1 PRIMARY KEY (id, created_at);


--
-- Name: tweets_2024_q2 tweets_2024_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q2
    ADD CONSTRAINT tweets_2024_q2_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2024_q3 tweets_2024_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q3
    ADD CONSTRAINT tweets_2024_q3_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2024_q4 tweets_2024_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q4
    ADD CONSTRAINT tweets_2024_q4_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2025_q1 tweets_2025_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q1
    ADD CONSTRAINT tweets_2025_q1_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2025_q2 tweets_2025_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q2
    ADD CONSTRAINT tweets_2025_q2_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2025_q3 tweets_2025_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q3
    ADD CONSTRAINT tweets_2025_q3_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2025_q4 tweets_2025_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q4
    ADD CONSTRAINT tweets_2025_q4_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2026_q1 tweets_2026_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q1
    ADD CONSTRAINT tweets_2026_q1_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2026_q2 tweets_2026_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q2
    ADD CONSTRAINT tweets_2026_q2_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2026_q3 tweets_2026_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q3
    ADD CONSTRAINT tweets_2026_q3_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_2026_q4 tweets_2026_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q4
    ADD CONSTRAINT tweets_2026_q4_pkey PRIMARY KEY (id, created_at);


--
-- Name: tweets_default tweets_default_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_default
    ADD CONSTRAINT tweets_default_pkey PRIMARY KEY (id, created_at);


--
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- Name: idx_follows_follower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_follows_follower ON public.follows USING btree (following_id, created_at DESC);


--
-- Name: idx_follows_following; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_follows_following ON public.follows USING btree (follower_id, created_at DESC);


--
-- Name: idx_likes_tweet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_likes_tweet ON public.likes USING btree (tweet_id, created_at DESC);


--
-- Name: idx_likes_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_likes_user ON public.likes USING btree (user_id, created_at DESC);


--
-- Name: idx_retweets_tweet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retweets_tweet ON public.retweets USING btree (tweet_id, created_at DESC);


--
-- Name: idx_retweets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retweets_user ON public.retweets USING btree (user_id, created_at DESC);


--
-- Name: idx_trending_hashtags; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_trending_hashtags ON public.trending_hashtags USING btree (hashtag);


--
-- Name: idx_tweets_timeline; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tweets_timeline ON ONLY public.tweets USING btree (user_id, created_at DESC);


--
-- Name: tweets_2024_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q1_user_id_created_at_idx ON public.tweets_2024_q1 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2024_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q2_user_id_created_at_idx ON public.tweets_2024_q2 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2024_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q3_user_id_created_at_idx ON public.tweets_2024_q3 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2024_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q4_user_id_created_at_idx ON public.tweets_2024_q4 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2025_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q1_user_id_created_at_idx ON public.tweets_2025_q1 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2025_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q2_user_id_created_at_idx ON public.tweets_2025_q2 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2025_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q3_user_id_created_at_idx ON public.tweets_2025_q3 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2025_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q4_user_id_created_at_idx ON public.tweets_2025_q4 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2026_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q1_user_id_created_at_idx ON public.tweets_2026_q1 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2026_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q2_user_id_created_at_idx ON public.tweets_2026_q2 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2026_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q3_user_id_created_at_idx ON public.tweets_2026_q3 USING btree (user_id, created_at DESC);


--
-- Name: tweets_2026_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q4_user_id_created_at_idx ON public.tweets_2026_q4 USING btree (user_id, created_at DESC);


--
-- Name: tweets_default_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_default_user_id_created_at_idx ON public.tweets_default USING btree (user_id, created_at DESC);


--
-- Name: tweets_2024_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q2_pkey;


--
-- Name: tweets_2024_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q2_user_id_created_at_idx;


--
-- Name: tweets_2024_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q3_pkey;


--
-- Name: tweets_2024_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q3_user_id_created_at_idx;


--
-- Name: tweets_2024_q4_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q4_pkey;


--
-- Name: tweets_2024_q4_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q4_user_id_created_at_idx;


--
-- Name: tweets_2025_q1_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q1_pkey;


--
-- Name: tweets_2025_q1_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q1_user_id_created_at_idx;


--
-- Name: tweets_2025_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q2_pkey;


--
-- Name: tweets_2025_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q2_user_id_created_at_idx;


--
-- Name: tweets_2025_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q3_pkey;


--
-- Name: tweets_2025_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q3_user_id_created_at_idx;


--
-- Name: tweets_2025_q4_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q4_pkey;


--
-- Name: tweets_2025_q4_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q4_user_id_created_at_idx;


--
-- Name: tweets_2026_q1_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q1_pkey;


--
-- Name: tweets_2026_q1_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q1_user_id_created_at_idx;


--
-- Name: tweets_2026_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q2_pkey;


--
-- Name: tweets_2026_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q2_user_id_created_at_idx;


--
-- Name: tweets_2026_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q3_pkey;


--
-- Name: tweets_2026_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q3_user_id_created_at_idx;


--
-- Name: tweets_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_default_pkey;


--
-- Name: tweets_default_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_default_user_id_created_at_idx;


--
-- Name: follows follow_counts_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER follow_counts_trigger AFTER INSERT OR DELETE ON public.follows FOR EACH ROW EXECUTE FUNCTION public.update_follow_counts();


--
-- Name: likes like_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER like_count_trigger AFTER INSERT OR DELETE ON public.likes FOR EACH ROW EXECUTE FUNCTION public.update_like_count();


--
-- Name: retweets retweet_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER retweet_count_trigger AFTER INSERT OR DELETE ON public.retweets FOR EACH ROW EXECUTE FUNCTION public.update_retweet_count();


--
-- Name: tweets tweet_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tweet_count_trigger AFTER INSERT OR DELETE ON public.tweets FOR EACH ROW EXECUTE FUNCTION public.update_tweet_count();


--
-- Name: tweets update_tweets_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_tweets_updated_at BEFORE UPDATE ON public.tweets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- Name: tweets fk_tweets_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tweets
    ADD CONSTRAINT fk_tweets_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: follows follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: follows follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: likes likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: retweets retweets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: trending_hashtags; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.trending_hashtags;


--
-- PostgreSQL database dump complete
--

\unrestrict ectY4a8qFFnFHvZGcANtco9gXhEaQZ64Kmi1SJ9p2NWnUpdeRJ4FFQyKioP4Wnx

