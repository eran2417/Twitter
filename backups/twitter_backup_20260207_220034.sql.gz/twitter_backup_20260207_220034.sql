pg_dump: last built-in OID is 16383
pg_dump: reading extensions
pg_dump: identifying extension members
pg_dump: reading schemas
pg_dump: reading user-defined tables
pg_dump: reading user-defined functions
pg_dump: reading user-defined types
pg_dump: reading procedural languages
pg_dump: reading user-defined aggregate functions
pg_dump: reading user-defined operators
pg_dump: reading user-defined access methods
pg_dump: reading user-defined operator classes
pg_dump: reading user-defined operator families
pg_dump: reading user-defined text search parsers
pg_dump: reading user-defined text search templates
pg_dump: reading user-defined text search dictionaries
pg_dump: reading user-defined text search configurations
pg_dump: reading user-defined foreign-data wrappers
pg_dump: reading user-defined foreign servers
pg_dump: reading default privileges
pg_dump: reading user-defined collations
pg_dump: reading user-defined conversions
pg_dump: reading type casts
pg_dump: reading transforms
pg_dump: reading table inheritance information
pg_dump: reading event triggers
pg_dump: finding extension tables
pg_dump: finding inheritance relationships
pg_dump: reading column info for interesting tables
pg_dump: finding table default expressions
pg_dump: finding table check constraints
pg_dump: flagging inherited columns in subtables
pg_dump: reading partitioning data
pg_dump: reading indexes
pg_dump: flagging indexes in partitioned tables
pg_dump: reading extended statistics
pg_dump: reading constraints
pg_dump: reading triggers
pg_dump: reading rewrite rules
pg_dump: reading policies
pg_dump: reading row-level security policies
pg_dump: reading publications
pg_dump: reading publication membership of tables
pg_dump: reading publication membership of schemas
pg_dump: reading subscriptions
pg_dump: reading large objects
pg_dump: reading dependency data
pg_dump: saving encoding = UTF8
pg_dump: saving standard_conforming_strings = on
pg_dump: saving search_path = 
--
-- PostgreSQL database dump
--

\restrict m6HvThV7kGlC4bnkEfdKixmsornwMZsARNYeQrr1Evuu64XHH20NHTTW8e1JvsS

-- Dumped from database version 15.15
-- Dumped by pg_dump version 15.15

-- Started on 2026-02-08 03:00:34 UTC

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_user_id_fkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_following_id_fkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_follower_id_fkey;
ALTER TABLE IF EXISTS public.tweets DROP CONSTRAINT IF EXISTS fk_tweets_user;
DROP TRIGGER IF EXISTS update_users_updated_at ON public.users;
DROP TRIGGER IF EXISTS update_tweets_updated_at ON public.tweets;
DROP TRIGGER IF EXISTS tweet_count_trigger ON public.tweets;
DROP TRIGGER IF EXISTS retweet_count_trigger ON public.retweets;
DROP TRIGGER IF EXISTS like_count_trigger ON public.likes;
DROP TRIGGER IF EXISTS follow_counts_trigger ON public.follows;
pg_dump: dropping FK CONSTRAINT retweets retweets_user_id_fkey
pg_dump: dropping FK CONSTRAINT likes likes_user_id_fkey
pg_dump: dropping FK CONSTRAINT follows follows_following_id_fkey
pg_dump: dropping FK CONSTRAINT follows follows_follower_id_fkey
pg_dump: dropping FK CONSTRAINT tweets fk_tweets_user
pg_dump: dropping TRIGGER users update_users_updated_at
pg_dump: dropping TRIGGER tweets update_tweets_updated_at
pg_dump: dropping TRIGGER tweets tweet_count_trigger
pg_dump: dropping TRIGGER retweets retweet_count_trigger
pg_dump: dropping TRIGGER likes like_count_trigger
pg_dump: dropping TRIGGER follows follow_counts_trigger
pg_dump: dropping INDEX tweets_default_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2026_q4_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2026_q3_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2026_q2_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2026_q1_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2025_q4_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2025_q3_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2025_q2_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2025_q1_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2024_q4_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2024_q3_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2024_q2_user_id_created_at_idx
pg_dump: dropping INDEX tweets_2024_q1_user_id_created_at_idx
pg_dump: dropping INDEX idx_tweets_timeline
pg_dump: dropping INDEX idx_trending_hashtags
pg_dump: dropping INDEX idx_retweets_user
pg_dump: dropping INDEX idx_retweets_tweet
pg_dump: dropping INDEX idx_likes_user
DROP INDEX IF EXISTS public.idx_tweets_timeline;
DROP INDEX IF EXISTS public.idx_trending_hashtags;
DROP INDEX IF EXISTS public.idx_retweets_user;
DROP INDEX IF EXISTS public.idx_retweets_tweet;
pg_dump: dropping INDEX idx_likes_tweet
pg_dump: dropping INDEX idx_follows_following
pg_dump: dropping INDEX idx_follows_follower
pg_dump: dropping CONSTRAINT users users_username_key
pg_dump: dropping CONSTRAINT users users_pkey
pg_dump: dropping CONSTRAINT users users_email_key
pg_dump: dropping CONSTRAINT tweets_default tweets_default_pkey
pg_dump: dropping CONSTRAINT tweets_2026_q4 tweets_2026_q4_pkey
pg_dump: dropping CONSTRAINT tweets_2026_q3 tweets_2026_q3_pkey
pg_dump: dropping CONSTRAINT tweets_2026_q2 tweets_2026_q2_pkey
pg_dump: dropping CONSTRAINT tweets_2026_q1 tweets_2026_q1_pkey
pg_dump:DROP INDEX IF EXISTS public.idx_likes_user;
DROP INDEX IF EXISTS public.idx_likes_tweet;
DROP INDEX IF EXISTS public.idx_follows_following;
DROP INDEX IF EXISTS public.idx_follows_follower;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_username_key;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_pkey;
ALTER TABLE IF EXISTS ONLY public.users DROP CONSTRAINT IF EXISTS users_email_key;
ALTER TABLE IF EXISTS ONLY public.tweets_default DROP CONSTRAINT IF EXISTS tweets_default_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q4 DROP CONSTRAINT IF EXISTS tweets_2026_q4_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q3 DROP CONSTRAINT IF EXISTS tweets_2026_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q2 DROP CONSTRAINT IF EXISTS tweets_2026_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2026_q1 DROP CONSTRAINT IF EXISTS tweets_2026_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q4 DROP CONSTRAINT IF EXISTS tweets_2025_q4_pkey;
 dropping CONSTRAINT tweets_2025_q4 tweets_2025_q4_pkey
pg_dump: dropping CONSTRAINT tweets_2025_q3 tweets_2025_q3_pkey
pg_dump: dropping CONSTRAINT tweets_2025_q2 tweets_2025_q2_pkey
pg_dump: dropping CONSTRAINT tweets_2025_q1 tweets_2025_q1_pkey
pg_dump: dropping CONSTRAINT tweets_2024_q4 tweets_2024_q4_pkey
pg_dump: dropping CONSTRAINT tweets_2024_q3 tweets_2024_q3_pkey
pg_dump: dropping CONSTRAINT tweets_2024_q2 tweets_2024_q2_pkey
pg_dump: dropping CONSTRAINT tweets_2024_q1 tweets_2024_q1_pkey
pg_dump: dropping CONSTRAINT tweets tweets_pkey1
pg_dump: dropping CONSTRAINT retweets retweets_user_id_tweet_id_key
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q3 DROP CONSTRAINT IF EXISTS tweets_2025_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q2 DROP CONSTRAINT IF EXISTS tweets_2025_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2025_q1 DROP CONSTRAINT IF EXISTS tweets_2025_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q4 DROP CONSTRAINT IF EXISTS tweets_2024_q4_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q3 DROP CONSTRAINT IF EXISTS tweets_2024_q3_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q2 DROP CONSTRAINT IF EXISTS tweets_2024_q2_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets_2024_q1 DROP CONSTRAINT IF EXISTS tweets_2024_q1_pkey;
ALTER TABLE IF EXISTS ONLY public.tweets DROP CONSTRAINT IF EXISTS tweets_pkey1;
ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_user_id_tweet_id_key;
ALTER TABLE IF EXISTS ONLY public.retweets DROP CONSTRAINT IF EXISTS retweets_pkey;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_user_id_tweet_id_key;
ALTER TABLE IF EXISTS ONLY public.likes DROP CONSTRAINT IF EXISTS likes_pkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_pkey;
ALTER TABLE IF EXISTS ONLY public.follows DROP CONSTRAINT IF EXISTS follows_follower_id_following_id_key;
ALTER TABLE IF EXISTS public.users ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.tweets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.retweets ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.likes ALTER COLUMN id DROP DEFAULT;
ALTER TABLE IF EXISTS public.follows ALTER COLUMN id DROP DEFAULT;
DROP SEQUENCE IF EXISTS public.users_id_seq;
DROP VIEW IF EXISTS public.user_timeline;
DROP TABLE IF EXISTS public.users;
DROP TABLE IF EXISTS public.tweets_default;
DROP TABLE IF EXISTS public.tweets_2026_q4;
DROP TABLE IF EXISTS public.tweets_2026_q3;
DROP TABLE IF EXISTS public.tweets_2026_q2;
DROP TABLE IF EXISTS public.tweets_2026_q1;
DROP TABLE IF EXISTS public.tweets_2025_q4;
DROP TABLE IF EXISTS public.tweets_2025_q3;
DROP TABLE IF EXISTS public.tweets_2025_q2;
DROP TABLE IF EXISTS public.tweets_2025_q1;
DROP TABLE IF EXISTS public.tweets_2024_q4;
DROP TABLE IF EXISTS public.tweets_2024_q3;
DROP TABLE IF EXISTS public.tweets_2024_q2;
DROP TABLE IF EXISTS public.tweets_2024_q1;
DROP SEQUENCE IF EXISTS public.tweets_id_seq1;
DROP MATERIALIZED VIEW IF EXISTS public.trending_hashtags;
DROP TABLE IF EXISTS public.tweets;
DROP SEQUENCE IF EXISTS public.retweets_id_seq1;
DROP SEQUENCE IF EXISTS public.retweets_id_seq;
DROP TABLE IF EXISTS public.retweets;
DROP SEQUENCE IF EXISTS public.likes_id_seq;
DROP TABLE IF EXISTS public.likes;
DROP SEQUENCE IF EXISTS public.follows_id_seq;
DROP TABLE IF EXISTS public.follows;
DROP FUNCTION IF EXISTS public.update_updated_at_column();
DROP FUNCTION IF EXISTS public.update_tweet_count();
DROP FUNCTION IF EXISTS public.update_retweet_count();
DROP FUNCTION IF EXISTS public.update_like_count();
DROP FUNCTION IF EXISTS public.update_follow_counts();
DROP FUNCTION IF EXISTS public.refresh_trending_hashtags();
DROP FUNCTION IF EXISTS datadog.explain_statement(l_query text, OUT explain json);
DROP SCHEMA IF EXISTS datadog;
--
-- TOC entry 5 (class 2615 OID 24731)
-- Name: datadog; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA datadog;


pg_dump: dropping CONSTRAINT retweets retweets_pkey
pg_dump: dropping CONSTRAINT likes likes_user_id_tweet_id_key
pg_dump: dropping CONSTRAINT likes likes_pkey
pg_dump: dropping CONSTRAINT follows follows_pkey
pg_dump: dropping CONSTRAINT follows follows_follower_id_following_id_key
pg_dump: dropping DEFAULT users id
pg_dump: dropping DEFAULT tweets id
pg_dump: dropping DEFAULT retweets id
pg_dump: dropping DEFAULT likes id
pg_dump: dropping DEFAULT follows id
pg_dump: dropping SEQUENCE users_id_seq
pg_dump: dropping VIEW user_timeline
pg_dump: dropping TABLE users
pg_dump: dropping TABLE tweets_default
pg_dump: dropping TABLE tweets_2026_q4
pg_dump: dropping TABLE tweets_2026_q3
pg_dump: dropping TABLE tweets_2026_q2
pg_dump: dropping TABLE tweets_2026_q1
pg_dump: dropping TABLE tweets_2025_q4
pg_dump: dropping TABLE tweets_2025_q3
pg_dump: dropping TABLE tweets_2025_q2
pg_dump: dropping TABLE tweets_2025_q1
pg_dump: dropping TABLE tweets_2024_q4
pg_dump: dropping TABLE tweets_2024_q3
pg_dump: dropping TABLE tweets_2024_q2
pg_dump: dropping TABLE tweets_2024_q1
pg_dump: dropping SEQUENCE tweets_id_seq1
pg_dump: dropping MATERIALIZED VIEW trending_hashtags
pg_dump: dropping TABLE tweets
pg_dump: dropping SEQUENCE retweets_id_seq1
pg_dump: dropping SEQUENCE retweets_id_seq
pg_dump: dropping TABLE retweets
pg_dump: dropping SEQUENCE likes_id_seq
pg_dump: dropping TABLE likes
pg_dump: dropping SEQUENCE follows_id_seq
pg_dump: dropping TABLE follows
pg_dump: dropping FUNCTION update_updated_at_column()
pg_dump: dropping FUNCTION update_tweet_count()
pg_dump: dropping FUNCTION update_retweet_count()
pg_dump: dropping FUNCTION update_like_count()
pg_dump: dropping FUNCTION update_follow_counts()
pg_dump: dropping FUNCTION refresh_trending_hashtags()
pg_dump: dropping FUNCTION explain_statement(text)
pg_dump: dropping SCHEMA datadog
pg_dump: creating SCHEMA "datadog"
pg_dump: creating FUNCTION "datadog.explain_statement(text)"
--
-- TOC entry 241 (class 1255 OID 24732)
-- Name: explain_statement(text); Type: FUNCTION; Schema: datadog; Owner: -
--

CREATE FUNCTION datadog.explain_statement(l_query text, OUT explain json) RETURNS SETOF json
    LANGUAGE plpgsql STRICT SECURITY DEFINER
    AS $$
DECLARE
curs REFCURSOR;
plan JSON;
BEGIN
   OPEN curs FOR EXECUTE 'EXPLAIN (FORMAT JSON) ' || l_query;
   FETCH curs INTO plan;
   CLOSE curs;
   RETURN QUERY SELECT plan;
END;
$$;


pg_dump: creating FUNCTION "public.refresh_trending_hashtags()"
pg_dump: creating FUNCTION "public.update_follow_counts()"
pg_dump: creating FUNCTION "public.update_like_count()"
pg_dump: creating FUNCTION "public.update_retweet_count()"
pg_dump: creating FUNCTION "public.update_tweet_count()"
pg_dump: creating FUNCTION "public.update_updated_at_column()"
pg_dump: creating TABLE "public.follows"
pg_dump: creating SEQUENCE "public.follows_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.follows_id_seq"
pg_dump: creating TABLE "public.likes"
pg_dump: creating SEQUENCE "public.likes_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.likes_id_seq"
pg_dump: creating TABLE "public.retweets"
pg_dump: creating SEQUENCE "public.retweets_id_seq"
pg_dump: creating SEQUENCE "public.retweets_id_seq1"
pg_dump: creating SEQUENCE OWNED BY "public.retweets_id_seq1"
--
-- TOC entry 247 (class 1255 OID 24734)
-- Name: refresh_trending_hashtags(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.refresh_trending_hashtags() RETURNS void
    LANGUAGE plpgsql
    AS $$
BEGIN
    REFRESH MATERIALIZED VIEW CONCURRENTLY trending_hashtags;
END;
$$;


--
-- TOC entry 243 (class 1255 OID 24735)
-- Name: update_follow_counts(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_follow_counts() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE users SET following_count = following_count + 1 WHERE id = NEW.follower_id;
        UPDATE users SET follower_count = follower_count + 1 WHERE id = NEW.following_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE users SET following_count = following_count - 1 WHERE id = OLD.follower_id;
        UPDATE users SET follower_count = follower_count - 1 WHERE id = OLD.following_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- TOC entry 245 (class 1255 OID 24736)
-- Name: update_like_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_like_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE tweets SET like_count = like_count + 1 WHERE id = NEW.tweet_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE tweets SET like_count = like_count - 1 WHERE id = OLD.tweet_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- TOC entry 246 (class 1255 OID 24737)
-- Name: update_retweet_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_retweet_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE tweets SET retweet_count = retweet_count + 1 WHERE id = NEW.tweet_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE tweets SET retweet_count = retweet_count - 1 WHERE id = OLD.tweet_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- TOC entry 244 (class 1255 OID 24738)
-- Name: update_tweet_count(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_tweet_count() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        UPDATE users SET tweet_count = tweet_count + 1 WHERE id = NEW.user_id;
    ELSIF TG_OP = 'DELETE' THEN
        UPDATE users SET tweet_count = tweet_count - 1 WHERE id = OLD.user_id;
    END IF;
    RETURN NULL;
END;
$$;


--
-- TOC entry 242 (class 1255 OID 24739)
-- Name: update_updated_at_column(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.update_updated_at_column() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- TOC entry 216 (class 1259 OID 24740)
-- Name: follows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.follows (
    id bigint NOT NULL,
    follower_id bigint NOT NULL,
    following_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    CONSTRAINT follows_check CHECK ((follower_id <> following_id))
);


--
-- TOC entry 217 (class 1259 OID 24745)
-- Name: follows_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.follows_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3752 (class 0 OID 0)
-- Dependencies: 217
-- Name: follows_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.follows_id_seq OWNED BY public.follows.id;


--
-- TOC entry 218 (class 1259 OID 24746)
-- Name: likes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.likes (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tweet_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 219 (class 1259 OID 24750)
-- Name: likes_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.likes_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3753 (class 0 OID 0)
-- Dependencies: 219
-- Name: likes_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.likes_id_seq OWNED BY public.likes.id;


--
-- TOC entry 223 (class 1259 OID 24851)
-- Name: retweets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.retweets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    tweet_id bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 220 (class 1259 OID 24751)
-- Name: retweets_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.retweets_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 222 (class 1259 OID 24850)
-- Name: retweets_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.retweets_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3754 (class 0 OID 0)
-- Dependencies: 222
-- Name: retweets_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.retweets_id_seq1 OWNED BY public.retweets.id;


--
-- TOC entry 225 (class 1259 OID 24875)
-- Name: tweets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
)
PARTITION BY RANGE (created_at);


--
-- TOC entry 239 (class 1259 OID 25155)
-- Name: trending_hashtags; Type: MATERIALIZED VIEW; Schema: public; Owner: -
--

CREATE MATERIALIZED VIEW public.trending_hashtags AS
 SELECT unnest(tweets.hashtags) AS hashtag,
    count(*) AS tweet_count,
    max(tweets.created_at) AS last_used
   FROM public.tweets
  WHERE (tweets.created_at > (now() - '24:00:00'::interval))
  GROUP BY (unnest(tweets.hashtags))
  ORDER BY (count(*)) DESC
 LIMIT 100
  WITH NO DATA;


--
-- TOC entry 224 (class 1259 OID 24874)
-- Name: tweets_id_seq1; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.tweets_id_seq1
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3755 (class 0 OID 0)
-- Dependencies: 224
-- Name: tweets_id_seq1; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.tweets_id_seq1 OWNED BY public.tweets.id;


--
-- TOC entry 226 (class 1259 OID 24887)
-- Name: tweets_2024_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 227 (class 1259 OID 24901)
-- Name: tweets_2024_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 228 (class 1259 OID 24915)
-- Name: tweets_2024_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 229 (class 1259 OID 24929)
-- Name: tweets_2024_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2024_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 230 (class 1259 OID 24943)
-- Name: tweets_2025_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 231 (class 1259 OID 24957)
-- Name: tweets_2025_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 232 (class 1259 OID 24971)
-- Name: tweets_2025_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 233 (class 1259 OID 24985)
-- Name: tweets_2025_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2025_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 234 (class 1259 OID 24999)
-- Name: tweets_2026_q1; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q1 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 235 (class 1259 OID 25013)
-- Name: tweets_2026_q2; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q2 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 236 (class 1259 OID 25027)
-- Name: tweets_2026_q3; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q3 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 237 (class 1259 OID 25041)
-- Name: tweets_2026_q4; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_2026_q4 (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 238 (class 1259 OID 25055)
-- Name: tweets_default; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tweets_default (
    id bigint DEFAULT nextval('public.tweets_id_seq1'::regclass) NOT NULL,
    user_id bigint NOT NULL,
    content text NOT NULL,
    reply_to_tweet_id bigint,
    media_urls text[],
    hashtags text[],
    mentions bigint[],
    like_count integer DEFAULT 0,
    retweet_count integer DEFAULT 0,
    reply_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now(),
    CONSTRAINT tweets_content_check1 CHECK ((length(content) <= 280))
);


--
-- TOC entry 215 (class 1259 OID 24578)
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id bigint NOT NULL,
    username character varying(15) NOT NULL,
    email character varying(254) NOT NULL,
    password_hash character varying(255) NOT NULL,
    display_name character varying(50) NOT NULL,
    bio text,
    avatar_url text,
    verified boolean DEFAULT false,
    follower_count integer DEFAULT 0,
    following_count integer DEFAULT 0,
    tweet_count integer DEFAULT 0,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone DEFAULT now()
);


--
-- TOC entry 240 (class 1259 OID 25162)
-- Name: user_timeline; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.user_timeline AS
 SELECT t.id,
    t.user_id,
    t.content,
    t.reply_to_tweet_id,
    t.media_urls,
    t.hashtags,
    t.mentions,
    t.like_count,
    t.retweet_count,
    t.reply_count,
    t.created_at,
    u.username,
    u.display_name,
    u.avatar_url,
    u.verified
   FROM (public.tweets t
     JOIN public.users u ON ((t.user_id = u.id)));


--
-- TOC entry 221 (class 1259 OID 24799)
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- TOC entry 3756 (class 0 OID 0)
-- Dependencies: 221
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


pg_dump: creating TABLE "public.tweets"
pg_dump: creating MATERIALIZED VIEW "public.trending_hashtags"
pg_dump: creating SEQUENCE "public.tweets_id_seq1"
pg_dump: creating SEQUENCE OWNED BY "public.tweets_id_seq1"
pg_dump: creating TABLE "public.tweets_2024_q1"
pg_dump: creating TABLE "public.tweets_2024_q2"
pg_dump: creating TABLE "public.tweets_2024_q3"
pg_dump: creating TABLE "public.tweets_2024_q4"
pg_dump: creating TABLE "public.tweets_2025_q1"
pg_dump: creating TABLE "public.tweets_2025_q2"
pg_dump: creating TABLE "public.tweets_2025_q3"
pg_dump: creating TABLE "public.tweets_2025_q4"
pg_dump: creating TABLE "public.tweets_2026_q1"
pg_dump: creating TABLE "public.tweets_2026_q2"
pg_dump: creating TABLE "public.tweets_2026_q3"
pg_dump: creating TABLE "public.tweets_2026_q4"
pg_dump: creating TABLE "public.tweets_default"
pg_dump: creating TABLE "public.users"
pg_dump: creating VIEW "public.user_timeline"
pg_dump: creating SEQUENCE "public.users_id_seq"
pg_dump: creating SEQUENCE OWNED BY "public.users_id_seq"
pg_dump: creating TABLE ATTACH "public.tweets_2024_q1"
pg_dump: creating TABLE ATTACH "public.tweets_2024_q2"
pg_dump: creating TABLE ATTACH "public.tweets_2024_q3"
pg_dump: creating TABLE ATTACH "public.tweets_2024_q4"
pg_dump: creating TABLE ATTACH "public.tweets_2025_q1"
pg_dump: creating TABLE ATTACH "public.tweets_2025_q2"
pg_dump: creating TABLE ATTACH "public.tweets_2025_q3"
pg_dump: creating TABLE ATTACH "public.tweets_2025_q4"
pg_dump: creating TABLE ATTACH "public.tweets_2026_q1"
pg_dump: creating TABLE ATTACH "public.tweets_2026_q2"
pg_dump: creating TABLE ATTACH "public.tweets_2026_q3"
--
-- TOC entry 3350 (class 0 OID 0)
-- Name: tweets_2024_q1; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q1 FOR VALUES FROM ('2024-01-01 00:00:00+00') TO ('2024-04-01 00:00:00+00');


--
-- TOC entry 3351 (class 0 OID 0)
-- Name: tweets_2024_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q2 FOR VALUES FROM ('2024-04-01 00:00:00+00') TO ('2024-07-01 00:00:00+00');


--
-- TOC entry 3352 (class 0 OID 0)
-- Name: tweets_2024_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q3 FOR VALUES FROM ('2024-07-01 00:00:00+00') TO ('2024-10-01 00:00:00+00');


--
-- TOC entry 3353 (class 0 OID 0)
-- Name: tweets_2024_q4; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2024_q4 FOR VALUES FROM ('2024-10-01 00:00:00+00') TO ('2025-01-01 00:00:00+00');


--
-- TOC entry 3354 (class 0 OID 0)
-- Name: tweets_2025_q1; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q1 FOR VALUES FROM ('2025-01-01 00:00:00+00') TO ('2025-04-01 00:00:00+00');


--
-- TOC entry 3355 (class 0 OID 0)
-- Name: tweets_2025_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q2 FOR VALUES FROM ('2025-04-01 00:00:00+00') TO ('2025-07-01 00:00:00+00');


--
-- TOC entry 3356 (class 0 OID 0)
-- Name: tweets_2025_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q3 FOR VALUES FROM ('2025-07-01 00:00:00+00') TO ('2025-10-01 00:00:00+00');


--
-- TOC entry 3357 (class 0 OID 0)
-- Name: tweets_2025_q4; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2025_q4 FOR VALUES FROM ('2025-10-01 00:00:00+00') TO ('2026-01-01 00:00:00+00');


--
-- TOC entry 3358 (class 0 OID 0)
-- Name: tweets_2026_q1; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q1 FOR VALUES FROM ('2026-01-01 00:00:00+00') TO ('2026-04-01 00:00:00+00');


--
-- TOC entry 3359 (class 0 OID 0)
-- Name: tweets_2026_q2; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q2 FOR VALUES FROM ('2026-04-01 00:00:00+00') TO ('2026-07-01 00:00:00+00');


--
-- TOC entry 3360 (class 0 OID 0)
-- Name: tweets_2026_q3; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q3 FOR VALUES FROM ('2026-07-01 00:00:00+00') TO ('2026-10-01 00:00:00+00');


pg_dump: creating TABLE ATTACH "public.tweets_2026_q4"
pg_dump: creating TABLE ATTACH "public.tweets_default"
pg_dump: creating DEFAULT "public.follows id"
pg_dump: creating DEFAULT "public.likes id"
pg_dump: creating DEFAULT "public.retweets id"
pg_dump: creating DEFAULT "public.tweets id"
pg_dump: creating DEFAULT "public.users id"
pg_dump: processing data for table "public.follows"
pg_dump: dumping contents of table "public.follows"
--
-- TOC entry 3361 (class 0 OID 0)
-- Name: tweets_2026_q4; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_2026_q4 FOR VALUES FROM ('2026-10-01 00:00:00+00') TO ('2027-01-01 00:00:00+00');


--
-- TOC entry 3362 (class 0 OID 0)
-- Name: tweets_default; Type: TABLE ATTACH; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ATTACH PARTITION public.tweets_default DEFAULT;


--
-- TOC entry 3370 (class 2604 OID 24800)
-- Name: follows id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows ALTER COLUMN id SET DEFAULT nextval('public.follows_id_seq'::regclass);


--
-- TOC entry 3372 (class 2604 OID 24801)
-- Name: likes id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes ALTER COLUMN id SET DEFAULT nextval('public.likes_id_seq'::regclass);


--
-- TOC entry 3374 (class 2604 OID 24854)
-- Name: retweets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets ALTER COLUMN id SET DEFAULT nextval('public.retweets_id_seq1'::regclass);


--
-- TOC entry 3376 (class 2604 OID 24878)
-- Name: tweets id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets ALTER COLUMN id SET DEFAULT nextval('public.tweets_id_seq1'::regclass);


--
-- TOC entry 3363 (class 2604 OID 24802)
-- Name: users id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- TOC entry 3724 (class 0 OID 24740)
-- Dependencies: 216
-- Data for Name: follows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.follows (id, follower_id, following_id, created_at) FROM stdin;
1	5	4	2026-02-08 02:57:33.241162+00
\.


--
-- TOC entry 3726 (class 0 OID 24746)
-- Dependencies: 218
-- Data for Name: likes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.likes (id, user_id, tweet_id, created_at) FROM stdin;
pg_dump: processing data for table "public.likes"
pg_dump: dumping contents of table "public.likes"
\.


--
-- TOC entry 3731 (class 0 OID 24851)
-- Dependencies: 223
-- Data for Name: retweets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.retweets (id, user_id, tweet_id, created_at) FROM stdin;
pg_dump: processing data for table "public.retweets"
pg_dump: dumping contents of table "public.retweets"
\.


--
-- TOC entry 3733 (class 0 OID 24887)
-- Dependencies: 226
-- Data for Name: tweets_2024_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2024_q1"
pg_dump: dumping contents of table "public.tweets_2024_q1"
\.


--
-- TOC entry 3734 (class 0 OID 24901)
-- Dependencies: 227
-- Data for Name: tweets_2024_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2024_q2"
pg_dump: dumping contents of table "public.tweets_2024_q2"
\.


--
-- TOC entry 3735 (class 0 OID 24915)
-- Dependencies: 228
-- Data for Name: tweets_2024_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2024_q3"
pg_dump: dumping contents of table "public.tweets_2024_q3"
\.


--
-- TOC entry 3736 (class 0 OID 24929)
-- Dependencies: 229
-- Data for Name: tweets_2024_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2024_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2024_q4"
pg_dump: dumping contents of table "public.tweets_2024_q4"
\.


--
-- TOC entry 3737 (class 0 OID 24943)
-- Dependencies: 230
-- Data for Name: tweets_2025_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2025_q1"
pg_dump: dumping contents of table "public.tweets_2025_q1"
\.


--
-- TOC entry 3738 (class 0 OID 24957)
-- Dependencies: 231
-- Data for Name: tweets_2025_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2025_q2"
pg_dump: dumping contents of table "public.tweets_2025_q2"
\.


--
-- TOC entry 3739 (class 0 OID 24971)
-- Dependencies: 232
-- Data for Name: tweets_2025_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2025_q3"
pg_dump: dumping contents of table "public.tweets_2025_q3"
\.


--
-- TOC entry 3740 (class 0 OID 24985)
-- Dependencies: 233
-- Data for Name: tweets_2025_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2025_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2025_q4"
pg_dump: dumping contents of table "public.tweets_2025_q4"
\.


--
-- TOC entry 3741 (class 0 OID 24999)
-- Dependencies: 234
-- Data for Name: tweets_2026_q1; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q1 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2026_q1"
pg_dump: dumping contents of table "public.tweets_2026_q1"
6	4	Hi, This is first tweet from Era Chaudhary	\N	{}	{}	{}	0	0	0	2026-02-08 02:56:40.657326+00	2026-02-08 02:56:40.657326+00
7	4	Hi This is second from Era Chaudhary	\N	{}	{}	{}	0	0	0	2026-02-08 02:56:52.339378+00	2026-02-08 02:56:52.339378+00
8	5	Hi This is first tweet from Emma Claire	\N	{}	{}	{}	0	0	0	2026-02-08 02:57:51.071751+00	2026-02-08 02:57:51.071751+00
9	5	Hi This is second from Emma Claire	\N	{}	{}	{}	0	0	0	2026-02-08 02:58:03.279801+00	2026-02-08 02:58:03.279801+00
\.


--
-- TOC entry 3742 (class 0 OID 25013)
-- Dependencies: 235
-- Data for Name: tweets_2026_q2; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q2 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2026_q2"
pg_dump: dumping contents of table "public.tweets_2026_q2"
\.


--
-- TOC entry 3743 (class 0 OID 25027)
-- Dependencies: 236
-- Data for Name: tweets_2026_q3; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q3 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2026_q3"
pg_dump: dumping contents of table "public.tweets_2026_q3"
\.


--
-- TOC entry 3744 (class 0 OID 25041)
-- Dependencies: 237
-- Data for Name: tweets_2026_q4; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_2026_q4 (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_2026_q4"
pg_dump: dumping contents of table "public.tweets_2026_q4"
\.


--
-- TOC entry 3745 (class 0 OID 25055)
-- Dependencies: 238
-- Data for Name: tweets_default; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tweets_default (id, user_id, content, reply_to_tweet_id, media_urls, hashtags, mentions, like_count, retweet_count, reply_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.tweets_default"
pg_dump: dumping contents of table "public.tweets_default"
\.


--
-- TOC entry 3723 (class 0 OID 24578)
-- Dependencies: 215
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, username, email, password_hash, display_name, bio, avatar_url, verified, follower_count, following_count, tweet_count, created_at, updated_at) FROM stdin;
pg_dump: processing data for table "public.users"
pg_dump: dumping contents of table "public.users"
4	eran2417	erachaudhary2417@gmail.com	$2a$12$S0S/JuWdzLdNw3f7yuUcPuo95Um28ozH2c.TxmCbxcQlcJv9hOW0K	Era Chaudhary	\N	\N	f	1	0	2	2026-02-08 02:56:28.437459+00	2026-02-08 02:57:33.241162+00
5	ec2693	ec2693@nyu.edu	$2a$12$x5dhDiJuBpwunaMhB3adCuXLu3p90CDVk4bpVpKYV7Y2nMfnrO43G	Emma Claire	\N	\N	f	0	1	2	2026-02-08 02:57:23.657021+00	2026-02-08 02:58:03.279801+00
\.


--
-- TOC entry 3757 (class 0 OID 0)
-- Dependencies: 217
-- Name: follows_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.follows_id_seq', 1, true);


--
-- TOC entry 3758 (class 0 OID 0)
-- Dependencies: 219
-- Name: likes_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.likes_id_seq', 1, false);


--
-- TOC entry 3759 (class 0 OID 0)
-- Dependencies: 220
-- Name: retweets_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retweets_id_seq', 1, false);


--
-- TOC entry 3760 (class 0 OID 0)
-- Dependencies: 222
-- Name: retweets_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.retweets_id_seq1', 1, false);


--
-- TOC entry 3761 (class 0 OID 0)
-- Dependencies: 224
-- Name: tweets_id_seq1; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.tweets_id_seq1', 9, true);


--
-- TOC entry 3762 (class 0 OID 0)
-- Dependencies: 221
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 5, true);


--
-- TOC entry 3482 (class 2606 OID 24804)
-- Name: follows follows_follower_id_following_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_following_id_key UNIQUE (follower_id, following_id);


--
-- TOC entry 3484 (class 2606 OID 24806)
-- Name: follows follows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_pkey PRIMARY KEY (id);


--
-- TOC entry 3490 (class 2606 OID 24808)
-- Name: likes likes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_pkey PRIMARY KEY (id);


--
-- TOC entry 3492 (class 2606 OID 24810)
-- Name: likes likes_user_id_tweet_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_tweet_id_key UNIQUE (user_id, tweet_id);


--
-- TOC entry 3496 (class 2606 OID 24857)
-- Name: retweets retweets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_pkey PRIMARY KEY (id);


--
-- TOC entry 3498 (class 2606 OID 24859)
-- Name: retweets retweets_user_id_tweet_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_user_id_tweet_id_key UNIQUE (user_id, tweet_id);


--
-- TOC entry 3501 (class 2606 OID 24886)
-- Name: tweets tweets_pkey1; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets
    ADD CONSTRAINT tweets_pkey1 PRIMARY KEY (id, created_at);


--
-- TOC entry 3503 (class 2606 OID 24898)
-- Name: tweets_2024_q1 tweets_2024_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q1
    ADD CONSTRAINT tweets_2024_q1_pkey PRIMARY KEY (id, created_at);


pg_dump: executing SEQUENCE SET follows_id_seq
pg_dump: executing SEQUENCE SET likes_id_seq
pg_dump: executing SEQUENCE SET retweets_id_seq
pg_dump: executing SEQUENCE SET retweets_id_seq1
pg_dump: executing SEQUENCE SET tweets_id_seq1
pg_dump: executing SEQUENCE SET users_id_seq
pg_dump: creating CONSTRAINT "public.follows follows_follower_id_following_id_key"
pg_dump: creating CONSTRAINT "public.follows follows_pkey"
pg_dump: creating CONSTRAINT "public.likes likes_pkey"
pg_dump: creating CONSTRAINT "public.likes likes_user_id_tweet_id_key"
pg_dump: creating CONSTRAINT "public.retweets retweets_pkey"
pg_dump: creating CONSTRAINT "public.retweets retweets_user_id_tweet_id_key"
pg_dump: creating CONSTRAINT "public.tweets tweets_pkey1"
pg_dump: creating CONSTRAINT "public.tweets_2024_q1 tweets_2024_q1_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2024_q2 tweets_2024_q2_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2024_q3 tweets_2024_q3_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2024_q4 tweets_2024_q4_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2025_q1 tweets_2025_q1_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2025_q2 tweets_2025_q2_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2025_q3 tweets_2025_q3_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2025_q4 tweets_2025_q4_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2026_q1 tweets_2026_q1_pkey"
--
-- TOC entry 3506 (class 2606 OID 24912)
-- Name: tweets_2024_q2 tweets_2024_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q2
    ADD CONSTRAINT tweets_2024_q2_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3509 (class 2606 OID 24926)
-- Name: tweets_2024_q3 tweets_2024_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q3
    ADD CONSTRAINT tweets_2024_q3_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3512 (class 2606 OID 24940)
-- Name: tweets_2024_q4 tweets_2024_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2024_q4
    ADD CONSTRAINT tweets_2024_q4_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3515 (class 2606 OID 24954)
-- Name: tweets_2025_q1 tweets_2025_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q1
    ADD CONSTRAINT tweets_2025_q1_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3518 (class 2606 OID 24968)
-- Name: tweets_2025_q2 tweets_2025_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q2
    ADD CONSTRAINT tweets_2025_q2_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3521 (class 2606 OID 24982)
-- Name: tweets_2025_q3 tweets_2025_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q3
    ADD CONSTRAINT tweets_2025_q3_pkey PRIMARY KEY (id, created_at);


pg_dump: creating CONSTRAINT "public.tweets_2026_q2 tweets_2026_q2_pkey"
pg_dump: creating CONSTRAINT "public.tweets_2026_q3 tweets_2026_q3_pkey"
--
-- TOC entry 3524 (class 2606 OID 24996)
-- Name: tweets_2025_q4 tweets_2025_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2025_q4
    ADD CONSTRAINT tweets_2025_q4_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3527 (class 2606 OID 25010)
-- Name: tweets_2026_q1 tweets_2026_q1_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q1
    ADD CONSTRAINT tweets_2026_q1_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3530 (class 2606 OID 25024)
-- Name: tweets_2026_q2 tweets_2026_q2_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q2
    ADD CONSTRAINT tweets_2026_q2_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3533 (class 2606 OID 25038)
-- Name: tweets_2026_q3 tweets_2026_q3_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q3
    ADD CONSTRAINT tweets_2026_q3_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3536 (class 2606 OID 25052)
-- Name: tweets_2026_q4 tweets_2026_q4_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_2026_q4
    ADD CONSTRAINT tweets_2026_q4_pkey PRIMARY KEY (id, created_at);


pg_dump: creating CONSTRAINT "public.tweets_2026_q4 tweets_2026_q4_pkey"
pg_dump: creating CONSTRAINT "public.tweets_default tweets_default_pkey"
pg_dump: creating CONSTRAINT "public.users users_email_key"
--
-- TOC entry 3539 (class 2606 OID 25066)
-- Name: tweets_default tweets_default_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tweets_default
    ADD CONSTRAINT tweets_default_pkey PRIMARY KEY (id, created_at);


--
-- TOC entry 3476 (class 2606 OID 24812)
-- Name: users users_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_email_key UNIQUE (email);


pg_dump: creating CONSTRAINT "public.users users_pkey"
pg_dump: creating CONSTRAINT "public.users users_username_key"
--
-- TOC entry 3478 (class 2606 OID 24591)
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- TOC entry 3480 (class 2606 OID 24814)
-- Name: users users_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_username_key UNIQUE (username);


--
-- TOC entry 3485 (class 1259 OID 24815)
-- Name: idx_follows_follower; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_follows_follower ON public.follows USING btree (following_id, created_at DESC);


--
-- TOC entry 3486 (class 1259 OID 24870)
-- Name: idx_follows_following; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_follows_following ON public.follows USING btree (follower_id, created_at DESC);


--
-- TOC entry 3487 (class 1259 OID 24816)
-- Name: idx_likes_tweet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_likes_tweet ON public.likes USING btree (tweet_id, created_at DESC);


--
-- TOC entry 3488 (class 1259 OID 24817)
-- Name: idx_likes_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_likes_user ON public.likes USING btree (user_id, created_at DESC);


--
-- TOC entry 3493 (class 1259 OID 24871)
-- Name: idx_retweets_tweet; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retweets_tweet ON public.retweets USING btree (tweet_id, created_at DESC);


--
-- TOC entry 3494 (class 1259 OID 24872)
-- Name: idx_retweets_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_retweets_user ON public.retweets USING btree (user_id, created_at DESC);


--
-- TOC entry 3541 (class 1259 OID 25161)
-- Name: idx_trending_hashtags; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_trending_hashtags ON public.trending_hashtags USING btree (hashtag);


--
-- TOC entry 3499 (class 1259 OID 25069)
-- Name: idx_tweets_timeline; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tweets_timeline ON ONLY public.tweets USING btree (user_id, created_at DESC);


--
-- TOC entry 3504 (class 1259 OID 25070)
-- Name: tweets_2024_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q1_user_id_created_at_idx ON public.tweets_2024_q1 USING btree (user_id, created_at DESC);


--
-- TOC entry 3507 (class 1259 OID 25071)
-- Name: tweets_2024_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q2_user_id_created_at_idx ON public.tweets_2024_q2 USING btree (user_id, created_at DESC);


--
-- TOC entry 3510 (class 1259 OID 25072)
-- Name: tweets_2024_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q3_user_id_created_at_idx ON public.tweets_2024_q3 USING btree (user_id, created_at DESC);


--
-- TOC entry 3513 (class 1259 OID 25073)
-- Name: tweets_2024_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2024_q4_user_id_created_at_idx ON public.tweets_2024_q4 USING btree (user_id, created_at DESC);


--
-- TOC entry 3516 (class 1259 OID 25074)
-- Name: tweets_2025_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q1_user_id_created_at_idx ON public.tweets_2025_q1 USING btree (user_id, created_at DESC);


--
-- TOC entry 3519 (class 1259 OID 25075)
-- Name: tweets_2025_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q2_user_id_created_at_idx ON public.tweets_2025_q2 USING btree (user_id, created_at DESC);


--
-- TOC entry 3522 (class 1259 OID 25076)
-- Name: tweets_2025_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q3_user_id_created_at_idx ON public.tweets_2025_q3 USING btree (user_id, created_at DESC);


pg_dump: creating INDEX "public.idx_follows_follower"
pg_dump: creating INDEX "public.idx_follows_following"
pg_dump: creating INDEX "public.idx_likes_tweet"
pg_dump: creating INDEX "public.idx_likes_user"
pg_dump: creating INDEX "public.idx_retweets_tweet"
pg_dump: creating INDEX "public.idx_retweets_user"
pg_dump: creating INDEX "public.idx_trending_hashtags"
pg_dump: creating INDEX "public.idx_tweets_timeline"
pg_dump: creating INDEX "public.tweets_2024_q1_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2024_q2_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2024_q3_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2024_q4_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2025_q1_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2025_q2_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2025_q3_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2025_q4_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2026_q1_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2026_q2_user_id_created_at_idx"
--
-- TOC entry 3525 (class 1259 OID 25077)
-- Name: tweets_2025_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2025_q4_user_id_created_at_idx ON public.tweets_2025_q4 USING btree (user_id, created_at DESC);


--
-- TOC entry 3528 (class 1259 OID 25078)
-- Name: tweets_2026_q1_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q1_user_id_created_at_idx ON public.tweets_2026_q1 USING btree (user_id, created_at DESC);


pg_dump: creating INDEX "public.tweets_2026_q3_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_2026_q4_user_id_created_at_idx"
pg_dump: creating INDEX "public.tweets_default_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q1_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q1_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q2_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q2_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q3_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q3_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q4_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2024_q4_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q1_pkey"
--
-- TOC entry 3531 (class 1259 OID 25079)
-- Name: tweets_2026_q2_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q2_user_id_created_at_idx ON public.tweets_2026_q2 USING btree (user_id, created_at DESC);


--
-- TOC entry 3534 (class 1259 OID 25080)
-- Name: tweets_2026_q3_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q3_user_id_created_at_idx ON public.tweets_2026_q3 USING btree (user_id, created_at DESC);


--
-- TOC entry 3537 (class 1259 OID 25081)
-- Name: tweets_2026_q4_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_2026_q4_user_id_created_at_idx ON public.tweets_2026_q4 USING btree (user_id, created_at DESC);


--
-- TOC entry 3540 (class 1259 OID 25082)
-- Name: tweets_default_user_id_created_at_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX tweets_default_user_id_created_at_idx ON public.tweets_default USING btree (user_id, created_at DESC);


--
-- TOC entry 3542 (class 0 OID 0)
-- Name: tweets_2024_q1_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q1_pkey;


--
-- TOC entry 3543 (class 0 OID 0)
-- Name: tweets_2024_q1_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q1_user_id_created_at_idx;


--
-- TOC entry 3544 (class 0 OID 0)
-- Name: tweets_2024_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q2_pkey;


--
-- TOC entry 3545 (class 0 OID 0)
-- Name: tweets_2024_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q2_user_id_created_at_idx;


--
-- TOC entry 3546 (class 0 OID 0)
-- Name: tweets_2024_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q3_pkey;


--
-- TOC entry 3547 (class 0 OID 0)
-- Name: tweets_2024_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q3_user_id_created_at_idx;


--
-- TOC entry 3548 (class 0 OID 0)
-- Name: tweets_2024_q4_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2024_q4_pkey;


--
-- TOC entry 3549 (class 0 OID 0)
-- Name: tweets_2024_q4_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2024_q4_user_id_created_at_idx;


--
-- TOC entry 3550 (class 0 OID 0)
-- Name: tweets_2025_q1_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q1_pkey;


--
-- TOC entry 3551 (class 0 OID 0)
-- Name: tweets_2025_q1_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q1_user_id_created_at_idx;


--
-- TOC entry 3552 (class 0 OID 0)
-- Name: tweets_2025_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q2_pkey;


--
-- TOC entry 3553 (class 0 OID 0)
-- Name: tweets_2025_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q2_user_id_created_at_idx;


--
-- TOC entry 3554 (class 0 OID 0)
-- Name: tweets_2025_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q3_pkey;


--
-- TOC entry 3555 (class 0 OID 0)
-- Name: tweets_2025_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q3_user_id_created_at_idx;


--
-- TOC entry 3556 (class 0 OID 0)
-- Name: tweets_2025_q4_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2025_q4_pkey;


pg_dump: creating INDEX ATTACH "public.tweets_2025_q1_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q2_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q2_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q3_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q3_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q4_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2025_q4_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q1_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q1_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q2_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q2_user_id_created_at_idx"
--
-- TOC entry 3557 (class 0 OID 0)
-- Name: tweets_2025_q4_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2025_q4_user_id_created_at_idx;


--
-- TOC entry 3558 (class 0 OID 0)
-- Name: tweets_2026_q1_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q1_pkey;


--
-- TOC entry 3559 (class 0 OID 0)
-- Name: tweets_2026_q1_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q1_user_id_created_at_idx;


--
-- TOC entry 3560 (class 0 OID 0)
-- Name: tweets_2026_q2_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q2_pkey;


--
-- TOC entry 3561 (class 0 OID 0)
-- Name: tweets_2026_q2_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q2_user_id_created_at_idx;


--
-- TOC entry 3562 (class 0 OID 0)
-- Name: tweets_2026_q3_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q3_pkey;


--
-- TOC entry 3563 (class 0 OID 0)
-- Name: tweets_2026_q3_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q3_user_id_created_at_idx;


--
-- TOC entry 3564 (class 0 OID 0)
-- Name: tweets_2026_q4_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_2026_q4_pkey;


--
-- TOC entry 3565 (class 0 OID 0)
-- Name: tweets_2026_q4_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_2026_q4_user_id_created_at_idx;


--
-- TOC entry 3566 (class 0 OID 0)
-- Name: tweets_default_pkey; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.tweets_pkey1 ATTACH PARTITION public.tweets_default_pkey;


pg_dump: creating INDEX ATTACH "public.tweets_2026_q3_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q3_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q4_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_2026_q4_user_id_created_at_idx"
pg_dump: creating INDEX ATTACH "public.tweets_default_pkey"
pg_dump: creating INDEX ATTACH "public.tweets_default_user_id_created_at_idx"
pg_dump: creating TRIGGER "public.follows follow_counts_trigger"
pg_dump: creating TRIGGER "public.likes like_count_trigger"
pg_dump: creating TRIGGER "public.retweets retweet_count_trigger"
pg_dump: creating TRIGGER "public.tweets tweet_count_trigger"
--
-- TOC entry 3567 (class 0 OID 0)
-- Name: tweets_default_user_id_created_at_idx; Type: INDEX ATTACH; Schema: public; Owner: -
--

ALTER INDEX public.idx_tweets_timeline ATTACH PARTITION public.tweets_default_user_id_created_at_idx;


--
-- TOC entry 3574 (class 2620 OID 24821)
-- Name: follows follow_counts_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER follow_counts_trigger AFTER INSERT OR DELETE ON public.follows FOR EACH ROW EXECUTE FUNCTION public.update_follow_counts();


--
-- TOC entry 3575 (class 2620 OID 24822)
-- Name: likes like_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER like_count_trigger AFTER INSERT OR DELETE ON public.likes FOR EACH ROW EXECUTE FUNCTION public.update_like_count();


--
-- TOC entry 3576 (class 2620 OID 24873)
-- Name: retweets retweet_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER retweet_count_trigger AFTER INSERT OR DELETE ON public.retweets FOR EACH ROW EXECUTE FUNCTION public.update_retweet_count();


--
-- TOC entry 3577 (class 2620 OID 25141)
-- Name: tweets tweet_count_trigger; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER tweet_count_trigger AFTER INSERT OR DELETE ON public.tweets FOR EACH ROW EXECUTE FUNCTION public.update_tweet_count();


--
-- TOC entry 3578 (class 2620 OID 25127)
-- Name: tweets update_tweets_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_tweets_updated_at BEFORE UPDATE ON public.tweets FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3573 (class 2620 OID 24825)
-- Name: users update_users_updated_at; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER update_users_updated_at BEFORE UPDATE ON public.users FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();


--
-- TOC entry 3572 (class 2606 OID 25083)
-- Name: tweets fk_tweets_user; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE public.tweets
    ADD CONSTRAINT fk_tweets_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3568 (class 2606 OID 24831)
-- Name: follows follows_follower_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_follower_id_fkey FOREIGN KEY (follower_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3569 (class 2606 OID 24836)
-- Name: follows follows_following_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.follows
    ADD CONSTRAINT follows_following_id_fkey FOREIGN KEY (following_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- TOC entry 3570 (class 2606 OID 24841)
-- Name: likes likes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.likes
    ADD CONSTRAINT likes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


pg_dump: creating TRIGGER "public.tweets update_tweets_updated_at"
pg_dump: creating TRIGGER "public.users update_users_updated_at"
pg_dump: creating FK CONSTRAINT "public.tweets fk_tweets_user"
pg_dump: creating FK CONSTRAINT "public.follows follows_follower_id_fkey"
pg_dump: creating FK CONSTRAINT "public.follows follows_following_id_fkey"
pg_dump: creating FK CONSTRAINT "public.likes likes_user_id_fkey"
pg_dump: creating FK CONSTRAINT "public.retweets retweets_user_id_fkey"
--
-- TOC entry 3571 (class 2606 OID 24860)
-- Name: retweets retweets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.retweets
    ADD CONSTRAINT retweets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


pg_dump: creating MATERIALIZED VIEW DATA "public.trending_hashtags"
--
-- TOC entry 3746 (class 0 OID 25155)
-- Dependencies: 239 3748
-- Name: trending_hashtags; Type: MATERIALIZED VIEW DATA; Schema: public; Owner: -
--

REFRESH MATERIALIZED VIEW public.trending_hashtags;


-- Completed on 2026-02-08 03:00:34 UTC

--
-- PostgreSQL database dump complete
--

\unrestrict m6HvThV7kGlC4bnkEfdKixmsornwMZsARNYeQrr1Evuu64XHH20NHTTW8e1JvsS

